import com.example.mybtest.MybtestApplication;
import com.example.mybtest.entity.User;
import com.example.mybtest.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {MybtestApplication.class})
class MybtestApplicationTests {
    @Autowired
    private UserService userService;
    @Test
    void contextLoads() {

    }

}
