package com.example.mybtest;

import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
@MapperScan(basePackages = {"com.example.mybtest.dao"})
public class MybtestApplication {

    public static void main(String[] args) {
        SpringApplication.run(MybtestApplication.class, args);
    }

}
