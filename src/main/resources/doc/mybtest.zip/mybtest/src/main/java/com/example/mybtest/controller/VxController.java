package com.example.mybtest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("vx")
public class VxController {
    @RequestMapping("/test")
    public String getVX(){
        System.out.println("测试成功！");
        return "测试成功";
    }
}
